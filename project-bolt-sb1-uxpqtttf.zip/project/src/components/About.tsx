import React, { useEffect, useRef, useState } from 'react';
import { Award, BookOpen, Code2, Brain, GraduationCap, Languages, Target, Users, Zap } from 'lucide-react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const highlights = [
    {
      icon: <Award className="w-8 h-8" />,
      title: "Quality Engineering",
      description: "2+ years ensuring production-grade software quality through comprehensive testing methodologies",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: <Code2 className="w-8 h-8" />,
      title: "Data Engineering",
      description: "Azure Databricks, ADF, PySpark expertise with hands-on data pipeline validation",
      color: "from-indigo-500 to-indigo-600"
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI & Automation",
      description: "Agentic AI (Crew AI) and intelligent automation workflows using cutting-edge technologies",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Cloud Technologies",
      description: "Microsoft Azure certified with extensive hands-on cloud platform experience",
      color: "from-green-500 to-green-600"
    }
  ];

  const topCertifications = [
    "Microsoft Certified: Azure Data Fundamentals",
    "Career Essentials in Generative AI by Microsoft and LinkedIn",
    "Docker for Beginners: a Hands-On Practice Course (+12 hours)",
    "ISTQB Foundation Exam Prep",
    "DYKA Arduino Bootcamp"
  ];

  const languages = [
    { language: "Telugu", level: "Native", proficiency: 100 },
    { language: "English", level: "Professional", proficiency: 90 },
    { language: "Hindi", level: "Working", proficiency: 75 }
  ];

  const stats = [
    { icon: <Target className="w-6 h-6" />, label: "Projects Completed", value: "15+" },
    { icon: <Users className="w-6 h-6" />, label: "Teams Collaborated", value: "8+" },
    { icon: <Zap className="w-6 h-6" />, label: "Technologies Mastered", value: "12+" }
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden" ref={sectionRef}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <div className={`text-center mb-20 ${isVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            About <span className="gradient-text">Me</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-indigo-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Passionate about building reliable systems and transitioning into the exciting world of data engineering
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Professional Image */}
          <div className={`relative ${isVisible ? 'animate-fadeInLeft' : 'opacity-0'}`}>
            <div className="relative group">
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur-2xl opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
              <img
                src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                alt="Professional software developer working focused on laptop"
                className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover hover:scale-105 transition-transform duration-500"
              />
              
              {/* Floating Achievement Cards */}
              <div className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg p-4 animate-float">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">2+</div>
                  <div className="text-sm text-gray-600">Years Exp</div>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-4 animate-float" style={{ animationDelay: '1s' }}>
                <div className="text-center">
                  <div className="text-2xl font-bold text-indigo-600">Shell</div>
                  <div className="text-sm text-gray-600">Current Role</div>
                </div>
              </div>
            </div>
          </div>

          {/* Professional Story */}
          <div className={`space-y-8 ${isVisible ? 'animate-fadeInRight' : 'opacity-0'}`}>
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-gray-900">My Professional Journey</h3>
              
              <div className="space-y-4 text-lg text-gray-600 leading-relaxed">
                <p>
                  I'm a <span className="font-semibold text-blue-600">Software QA Engineer at Shell</span> with 2+ years of experience ensuring production-grade software quality through functional, integration, and mobile application testing.
                </p>
                
                <p>
                  My journey includes valuable experiences at <span className="font-semibold text-indigo-600">Zebra Technologies</span> working with custom Linux-based embedded OS builds, and at <span className="font-semibold text-purple-600">Chiplogic Technologies</span> developing components for 5G O-RAN systems.
                </p>
                
                <p>
                  I'm actively transitioning to <span className="font-semibold text-green-600">Data Engineering</span>, leveraging my experience with Azure Databricks, Azure Data Factory, and data pipeline validation. Passionate about innovative solutions in cloud data engineering and AI automation workflows.
                </p>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-6 pt-6 border-t border-gray-200">
              {stats.map((stat, index) => (
                <div key={index} className="text-center group hover:scale-105 transition-transform duration-300">
                  <div className="text-blue-600 mb-2 flex justify-center group-hover:scale-110 transition-transform duration-300">
                    {stat.icon}
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Expertise Highlights */}
        <div className={`mb-20 ${isVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-12">Core Expertise</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {highlights.map((item, index) => (
              <div 
                key={index} 
                className={`group relative p-8 bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 card-hover animate-fadeInUp stagger-${index + 1}`}
              >
                <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-5 transition-opacity duration-500 rounded-2xl"
                     style={{ background: `linear-gradient(135deg, var(--primary-500), var(--primary-600))` }}></div>
                
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br ${item.color} text-white mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  {item.icon}
                </div>
                
                <h4 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">
                  {item.title}
                </h4>
                
                <p className="text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Education, Certifications, and Languages Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Education */}
          <div className={`${isVisible ? 'animate-fadeInUp stagger-1' : 'opacity-0'}`}>
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-2xl h-full">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center mr-4">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Education</h3>
              </div>
              
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-xl shadow-sm">
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">B.E, Information Science Engineering</h4>
                  <p className="text-blue-600 font-medium mb-1">Ramaiah Institute Of Technology</p>
                  <p className="text-gray-500 text-sm">2019 - 2023</p>
                </div>
              </div>
            </div>
          </div>

          {/* Top Certifications */}
          <div className={`${isVisible ? 'animate-fadeInUp stagger-2' : 'opacity-0'}`}>
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-8 rounded-2xl h-full">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center mr-4">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Top Certifications</h3>
              </div>
              
              <div className="space-y-3">
                {topCertifications.map((cert, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300">
                    <div className="w-2 h-2 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-gray-700 text-sm leading-relaxed">{cert}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Languages */}
          <div className={`${isVisible ? 'animate-fadeInUp stagger-3' : 'opacity-0'}`}>
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-2xl h-full">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mr-4">
                  <Languages className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Languages</h3>
              </div>
              
              <div className="space-y-6">
                {languages.map((lang, index) => (
                  <div key={index} className="bg-white p-6 rounded-xl shadow-sm">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-semibold text-gray-900">{lang.language}</h4>
                      <span className="text-sm text-gray-600">{lang.level}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${lang.proficiency}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;