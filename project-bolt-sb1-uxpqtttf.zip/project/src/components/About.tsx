import React from 'react';
import { Award, BookOpen, Code2, Brain } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: <Award className="w-6 h-6" />,
      title: "Quality Assurance",
      description: "Ensuring top-notch software quality through rigorous testing"
    },
    {
      icon: <Code2 className="w-6 h-6" />,
      title: "Full Stack Development",
      description: "Building end-to-end solutions with modern technologies"
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "AI/ML Expertise",
      description: "Working with cutting-edge machine learning models"
    },
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "Continuous Learning",
      description: "Always staying updated with latest technologies"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">About Me</h2>
          <div className="mt-4 h-1 w-20 bg-blue-600 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          <div className="relative group">
            <img
              src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
              alt="Professional workspace"
              className="rounded-lg shadow-lg transform group-hover:scale-105 transition-all duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-indigo-600/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"></div>
          </div>
          <div className="space-y-6">
            <p className="text-lg text-gray-600">
              I'm a Software Engineer currently working as an Associate Quality Assurance Specialist at Shell, where I ensure top-notch software quality through rigorous testing and process optimization.
            </p>
            <p className="text-lg text-gray-600">
              My journey includes valuable experiences at Zebra Technologies and Chiplogic Technologies, where I worked with networking protocols, embedded systems, and 5G technologies.
            </p>
            <p className="text-lg text-gray-600">
              I'm passionate about solving complex problems and continuously improving systems to deliver high-impact, user-centric solutions.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
          {highlights.map((item, index) => (
            <div key={index} 
              className="p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 hover:bg-white">
              <div className="text-blue-600 mb-4">{item.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;