import React from 'react';
import { Github, Linkedin, Mail, ExternalLink } from 'lucide-react';

const SocialLinks = () => {
  const socialLinks = [
    {
      icon: <Github className="w-5 h-5" />,
      href: 'https://github.com/Saicharan2001',
      label: 'GitHub',
      color: 'hover:text-gray-900 hover:bg-gray-100'
    },
    {
      icon: <Linkedin className="w-5 h-5" />,
      href: 'https://www.linkedin.com/in/sai-charan-68b0141b2/',
      label: 'LinkedIn',
      color: 'hover:text-blue-600 hover:bg-blue-50'
    },
    {
      icon: <Mail className="w-5 h-5" />,
      href: 'mailto:saicharan2001kande@gmail.com',
      label: 'Email',
      color: 'hover:text-red-600 hover:bg-red-50'
    }
  ];

  return (
    <div className="flex items-center justify-center space-x-2 flex-wrap gap-2">
      {socialLinks.map((link, index) => (
        <a
          key={index}
          href={link.href}
          target={link.href.startsWith('http') ? '_blank' : '_self'}
          rel={link.href.startsWith('http') ? 'noopener noreferrer' : ''}
          className={`p-2 lg:p-3 rounded-xl text-gray-600 transition-all duration-300 hover:scale-110 hover:shadow-lg ${link.color} group flex-shrink-0`}
          aria-label={link.label}
        >
          <div className="group-hover:scale-110 transition-transform duration-300">
            {link.icon}
          </div>
        </a>
      ))}
    </div>
  );
};

export default SocialLinks;