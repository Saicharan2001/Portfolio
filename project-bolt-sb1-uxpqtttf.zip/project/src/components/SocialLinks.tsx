import React from 'react';
import { Github, Linkedin, Mail } from 'lucide-react';

const SocialLinks = () => {
  return (
    <div className="flex space-x-4">
      <a href="https://github.com" target="_blank" rel="noopener noreferrer" 
        className="text-gray-600 hover:text-blue-600 transform hover:scale-110 transition-all">
        <Github className="w-6 h-6" />
      </a>
      <a href="https://www.linkedin.com/in/saicharan-68b0141b2" target="_blank" rel="noopener noreferrer"
        className="text-gray-600 hover:text-blue-600 transform hover:scale-110 transition-all">
        <Linkedin className="w-6 h-6" />
      </a>
      <a href="mailto:saicharan2001kande@gmail.com"
        className="text-gray-600 hover:text-blue-600 transform hover:scale-110 transition-all">
        <Mail className="w-6 h-6" />
      </a>
    </div>
  );
};

export default SocialLinks;