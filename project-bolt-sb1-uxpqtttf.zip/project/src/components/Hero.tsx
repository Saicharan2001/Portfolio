import React from 'react';
import { ArrowRight } from 'lucide-react';
import SocialLinks from './SocialLinks';

const Hero = () => {
  return (
    <section id="home" className="min-h-screen relative overflow-hidden">
      {/* Background with subtle animation */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-indigo-50 animate-gradient"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 flex flex-col md:flex-row items-center justify-between">
        <div className="text-left md:w-1/2 mb-12 md:mb-0">
          <div className="animate-fadeIn">
            <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 mb-6">
              Hi, I'm <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Sai Charan</span>
            </h1>
            <p className="text-xl sm:text-2xl text-gray-600 mb-8">
              Software Engineer at Shell | Quality Assurance Specialist
            </p>
            <p className="text-lg text-gray-600 max-w-2xl mb-12">
              Passionate about solving complex problems and delivering high-impact solutions through innovation and continuous learning.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <a
                href="#contact"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transform hover:scale-105 transition-all"
              >
                Get in Touch
                <ArrowRight className="ml-2 w-4 h-4" />
              </a>
              <a
                href="#experience"
                className="inline-flex items-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transform hover:scale-105 transition-all"
              >
                View Experience
              </a>
            </div>

            <div className="mt-8 md:hidden">
              <SocialLinks />
            </div>
          </div>
        </div>

        <div className="md:w-1/2 animate-fadeInRight">
          <img
            src="https://images.unsplash.com/photo-1537432376769-00f5c2f4c8d2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
            alt="Professional software developer working with multiple screens"
            className="rounded-lg shadow-2xl transform hover:scale-105 transition-all duration-300 hover:shadow-blue-200"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;