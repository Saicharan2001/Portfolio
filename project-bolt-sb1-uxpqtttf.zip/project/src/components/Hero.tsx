import React, { useEffect, useState } from 'react';
import { ArrowRight, Download, MapPin, Briefcase } from 'lucide-react';
import SocialLinks from './SocialLinks';

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const roles = [
    "Software QA Engineer",
    "Aspiring Data Engineer", 
    "Cloud Enthusiast",
    "Azure Specialist"
  ];

  const [currentRole, setCurrentRole] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentRole((prev) => (prev + 1) % roles.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="home" className="min-h-screen relative overflow-hidden bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float" style={{ animationDelay: '4s' }}></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Content */}
          <div className={`space-y-8 ${isVisible ? 'animate-fadeInLeft' : 'opacity-0'}`}>
            {/* Status Badge */}
            <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium animate-pulse">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              Available for Data Engineering Roles
            </div>

            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-7xl font-bold text-gray-900 leading-tight">
                Hi, I'm{' '}
                <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Sai Charan
                </span>
              </h1>
              
              {/* Animated Role */}
              <div className="h-16 flex items-center">
                <span className="text-2xl lg:text-3xl text-gray-600 font-medium">
                  {roles[currentRole]}
                </span>
              </div>
            </div>

            {/* Description */}
            <p className="text-xl text-gray-600 leading-relaxed max-w-2xl">
              Software QA Engineer at Shell with 2+ years of experience ensuring production-grade quality. 
              Transitioning to Data Engineering with expertise in{' '}
              <span className="font-semibold text-blue-600">Azure Databricks</span>,{' '}
              <span className="font-semibold text-blue-600">ADF</span>, and{' '}
              <span className="font-semibold text-blue-600">PySpark</span>.
            </p>

            {/* Key Stats */}
            <div className="grid grid-cols-2 gap-6 py-6">
              <div className="text-center lg:text-left">
                <div className="text-3xl font-bold text-blue-600">2+</div>
                <div className="text-gray-600">Years Experience</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-3xl font-bold text-indigo-600">5+</div>
                <div className="text-gray-600">Certifications</div>
              </div>
            </div>

            {/* Location & Company */}
            <div className="flex flex-wrap gap-6 text-gray-600">
              <div className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-blue-600" />
                <span>Software QA Engineer at Shell</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-blue-600" />
                <span>Bangalore, India</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href="#contact"
                className="btn-primary hover-lift micro-bounce"
              >
                Get in Touch
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#experience"
                className="btn-secondary hover-lift micro-bounce"
              >
                View Experience
              </a>
              <button className="btn-secondary hover-lift micro-bounce">
                <Download className="w-5 h-5" />
                Resume
              </button>
            </div>

            {/* Social Links - Mobile */}
            <div className="lg:hidden pt-6">
              <SocialLinks />
            </div>
          </div>

          {/* Hero Image */}
          <div className={`relative ${isVisible ? 'animate-fadeInRight' : 'opacity-0'}`}>
            <div className="relative group">
              {/* Main Image */}
              <div className="relative overflow-hidden rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-500 hover:scale-105">
                <img
                  src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                  alt="Professional software developer working on laptop"
                  className="w-full h-[600px] object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent"></div>
              </div>

              {/* Floating Cards */}
              <div className="absolute -top-6 -left-6 bg-white rounded-xl shadow-lg p-4 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700">Available for hire</span>
                </div>
              </div>

              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-lg p-4 animate-float" style={{ animationDelay: '1s' }}>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">Shell</div>
                  <div className="text-sm text-gray-600">Current Company</div>
                </div>
              </div>

              {/* Background Decoration */}
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur-2xl opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-gray-400 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-gray-400 rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;