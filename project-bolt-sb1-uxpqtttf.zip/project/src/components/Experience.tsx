import React, { useEffect, useRef, useState } from 'react';
import { Building2, Calendar, MapPin, ChevronRight, Award, Users, Target } from 'lucide-react';

const Experience = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const experiences = [
    {
      company: 'Shell',
      positions: [
        {
          title: 'Software QA Engineer',
          duration: 'February 2025 - Present',
          description: 'Performing mobile application automation testing, focusing on stability and regression coverage across releases. Ensuring accurate functional validation of transaction flows across integrated components.',
          achievements: [
            'Performed mobile application automation testing, focusing on stability and regression coverage across releases',
            'Ensured accurate functional validation of transaction flows across integrated components, collaborating with cross-functional teams to identify and resolve issues early'
          ]
        },
        {
          title: 'Associate Software QA Specialist',
          duration: 'August 2023 - March 2025',
          description: 'Executed end-to-end functional testing, System Testing (ST), and System Integration Testing (SIT) for a large-scale Payment Settlement System.',
          achievements: [
            'Executed end-to-end functional testing, System Testing (ST), and System Integration Testing (SIT) for a large-scale Payment Settlement System, supporting phased rollouts across multiple regions and ensuring smooth go-live transitions',
            'Contributed defect identification, triage, and test lifecycle management, working closely with development and platform teams to improve overall system stability and accelerate high-quality releases',
            'Collaborated with data engineering and platform teams to understand data ingestion, transformations, and pipelines, validating output data as part of end-to-end quality assurance',
            'Gained strong working understanding of data platforms leveraging Azure Databricks and Azure Data Factory, including pipeline dependencies, data flow behavior, to effectively support testing, validation, and production readiness'
          ]
        }
      ],
      location: 'Bangalore Urban, Karnataka, India',
      image: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80',
      color: 'from-blue-500 to-blue-600',
      totalDuration: '2 years 5 months'
    },
    {
      company: 'Zebra Technologies',
      positions: [
        {
          title: 'Software Developer Intern',
          duration: 'January 2023 - July 2023',
          description: 'Contributed to custom Linux-based embedded OS builds using the Yocto Project.',
          achievements: [
            'Contributed to custom Linux-based embedded OS builds using the Yocto Project, gaining hands-on exposure to system-level configuration and deployment',
            'Implemented terminal-level functionalities for embedded devices using JavaScript, working close to the OS runtime environment',
            'Strengthened understanding of operating systems, system debugging, and hardware–software interaction through real-world development work'
          ]
        }
      ],
      location: 'Bangalore Urban, Karnataka, India',
      image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80',
      color: 'from-indigo-500 to-indigo-600',
      totalDuration: '7 months'
    },
    {
      company: 'Chiplogic Technologies',
      positions: [
        {
          title: 'Student Intern Software Developer',
          duration: 'February 2022 - January 2023',
          description: 'Developed and unit-tested components for network management and time synchronization in 5G O-RAN systems.',
          achievements: [
            'Developed and unit-tested components for network management and time synchronization in 5G O-RAN systems',
            'Implemented custom logic for NETCONF and partial PTP protocols using Python and C++, based on reference implementations',
            'Built strong foundations in networking concepts and protocols, distributed systems behavior, message flows and synchronization logic'
          ]
        }
      ],
      location: 'Bangalore Urban, Karnataka, India',
      image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80',
      color: 'from-purple-500 to-purple-600',
      totalDuration: '1 year'
    }
  ];

  return (
    <section id="experience" className="py-24 bg-gradient-to-br from-gray-50 to-blue-50 relative overflow-hidden" ref={sectionRef}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000000' fill-opacity='0.1'%3E%3Cpath d='M20 20c0-11.046-8.954-20-20-20v20h20z'/%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <div className={`text-center mb-20 ${isVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Professional <span className="gradient-text">Experience</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-indigo-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A journey through quality engineering, embedded systems, and data platforms
          </p>
        </div>

        {/* Experience Timeline */}
        <div className="space-y-16">
          {experiences.map((exp, index) => (
            <div
              key={index}
              className={`relative ${isVisible ? `animate-fadeInUp stagger-${index + 1}` : 'opacity-0'}`}
            >
              {/* Company Card */}
              <div className="bg-white rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden group hover:-translate-y-2">
                <div className="lg:flex">
                  {/* Company Image */}
                  <div className="lg:w-2/5 relative overflow-hidden">
                    <img 
                      src={exp.image}
                      alt={exp.company}
                      className="h-full w-full object-cover object-center min-h-[300px] lg:min-h-[400px] group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className={`absolute inset-0 bg-gradient-to-br ${exp.color} opacity-20 group-hover:opacity-30 transition-opacity duration-500`}></div>
                    
                    {/* Company Badge */}
                    <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-sm rounded-xl px-4 py-2 shadow-lg">
                      <div className="flex items-center gap-3">
                        <Building2 className="w-5 h-5 text-gray-700" />
                        <span className="font-semibold text-gray-900">{exp.company}</span>
                      </div>
                    </div>

                    {/* Duration Badge */}
                    <div className="absolute bottom-6 right-6 bg-white/90 backdrop-blur-sm rounded-xl px-4 py-2 shadow-lg">
                      <div className="text-center">
                        <div className="text-sm font-semibold text-gray-900">{exp.totalDuration}</div>
                        <div className="text-xs text-gray-600">Total Duration</div>
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="lg:w-3/5 p-8 lg:p-12">
                    <div className="space-y-8">
                      {/* Company Header */}
                      <div className="border-b border-gray-200 pb-6">
                        <h3 className="text-3xl font-bold text-gray-900 mb-4">{exp.company}</h3>
                        <div className="flex items-center text-gray-600 mb-2">
                          <MapPin className="w-4 h-4 mr-2" />
                          <span>{exp.location}</span>
                        </div>
                      </div>

                      {/* Positions */}
                      <div className="space-y-8">
                        {exp.positions.map((position, posIndex) => (
                          <div key={posIndex} className="relative">
                            {/* Position Header */}
                            <div className="mb-6">
                              <h4 className="text-xl font-bold text-gray-900 mb-2">{position.title}</h4>
                              <div className="flex items-center text-gray-600 mb-4">
                                <Calendar className="w-4 h-4 mr-2" />
                                <span className="font-medium">{position.duration}</span>
                              </div>
                              <p className="text-gray-600 leading-relaxed">{position.description}</p>
                            </div>

                            {/* Key Achievements */}
                            <div className="space-y-3">
                              <h5 className="font-semibold text-gray-900 flex items-center gap-2">
                                <Award className="w-4 h-4 text-blue-600" />
                                Key Achievements
                              </h5>
                              <ul className="space-y-2">
                                {position.achievements.map((achievement, achIndex) => (
                                  <li key={achIndex} className="flex items-start gap-3 text-gray-600">
                                    <ChevronRight className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                    <span className="leading-relaxed">{achievement}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* Separator for multiple positions */}
                            {posIndex < exp.positions.length - 1 && (
                              <div className="mt-8 pt-8 border-t border-gray-100"></div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Timeline Connector */}
              {index < experiences.length - 1 && (
                <div className="flex justify-center my-12">
                  <div className="w-px h-16 bg-gradient-to-b from-blue-600 to-indigo-600 relative">
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-lg"></div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Career Highlights Summary */}
        <div className={`mt-20 ${isVisible ? 'animate-fadeInUp stagger-4' : 'opacity-0'}`}>
          <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
            <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Career Highlights</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Quality Focus</h4>
                <p className="text-gray-600">Ensured production-grade quality across multiple large-scale systems</p>
              </div>
              
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Cross-functional</h4>
                <p className="text-gray-600">Collaborated with development, data engineering, and platform teams</p>
              </div>
              
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Technical Growth</h4>
                <p className="text-gray-600">Evolved from embedded systems to cloud data platforms</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;