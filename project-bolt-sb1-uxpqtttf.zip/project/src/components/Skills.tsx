import React, { useEffect, useRef, useState } from 'react';
import { Code2, Database, Cloud, Brain, Zap, Shield, Network, Cpu } from 'lucide-react';

const Skills = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const skillCategories = [
    {
      title: 'Data Engineering',
      icon: <Database className="w-8 h-8" />,
      color: 'from-blue-500 to-blue-600',
      skills: [
        { name: 'Azure Databricks', level: 85 },
        { name: 'Azure Data Factory', level: 80 },
        { name: 'PySpark', level: 75 },
        { name: 'SQL', level: 90 }
      ],
    },
    {
      title: 'Cloud & DevOps',
      icon: <Cloud className="w-8 h-8" />,
      color: 'from-indigo-500 to-indigo-600',
      skills: [
        { name: 'Microsoft Azure', level: 85 },
        { name: 'Docker', level: 80 },
        { name: 'Python', level: 90 },
        { name: 'JavaScript', level: 75 }
      ],
    },
    {
      title: 'Quality Assurance',
      icon: <Shield className="w-8 h-8" />,
      color: 'from-purple-500 to-purple-600',
      skills: [
        { name: 'Mobile App Testing', level: 90 },
        { name: 'Functional Testing', level: 95 },
        { name: 'Integration Testing', level: 85 },
        { name: 'Python Automation', level: 80 }
      ],
    },
    {
      title: 'Specialized Tech',
      icon: <Cpu className="w-8 h-8" />,
      color: 'from-green-500 to-green-600',
      skills: [
        { name: '5G O-RAN Protocols', level: 70 },
        { name: 'NETCONF', level: 65 },
        { name: 'Embedded Systems', level: 75 },
        { name: 'Yocto Project', level: 70 }
      ],
    },
  ];

  const topSkills = [
    { name: 'Azure Databricks', icon: '🔷', category: 'Data Engineering' },
    { name: 'Azure Data Factory', icon: '🏭', category: 'Data Engineering' },
    { name: 'PySpark', icon: '⚡', category: 'Big Data' },
    { name: 'Python', icon: '🐍', category: 'Programming' },
    { name: 'SQL', icon: '🗃️', category: 'Database' },
    { name: 'Mobile Testing', icon: '📱', category: 'QA Engineering' }
  ];

  const aiTools = [
    { name: 'Crew AI', description: 'Agentic AI workflows', icon: '🤖' },
    { name: 'Make.com', description: 'AI automation workflows', icon: '⚙️' },
    { name: 'Azure AI', description: 'Cloud AI services', icon: '☁️' }
  ];

  return (
    <section id="skills" className="py-24 bg-white relative overflow-hidden" ref={sectionRef}>
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-float"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <div className={`text-center mb-20 ${isVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Skills & <span className="gradient-text">Expertise</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-indigo-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A comprehensive toolkit spanning data engineering, quality assurance, and cutting-edge technologies
          </p>
        </div>

        {/* Top Skills Showcase */}
        <div className={`mb-16 lg:mb-20 ${isVisible ? 'animate-fadeInUp stagger-1' : 'opacity-0'}`}>
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">Featured Skills</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-6">
            {topSkills.map((skill, index) => (
              <div 
                key={index}
                className="group bg-gradient-to-br from-white to-gray-50 p-4 lg:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 text-center min-h-[120px] flex flex-col justify-center"
              >
                <div className="text-3xl lg:text-4xl mb-2 lg:mb-3 group-hover:scale-110 transition-transform duration-300">
                  {skill.icon}
                </div>
                <h4 className="font-bold text-gray-900 mb-1 text-xs lg:text-sm leading-tight">{skill.name}</h4>
                <p className="text-xs text-gray-600 leading-tight">{skill.category}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Detailed Skills Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 mb-16 lg:mb-20">
          {skillCategories.map((category, index) => (
            <div 
              key={index} 
              className={`bg-gradient-to-br from-white to-gray-50 p-6 lg:p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 ${isVisible ? `animate-fadeInUp stagger-${index + 2}` : 'opacity-0'}`}
            >
              <div className="flex items-center mb-6 lg:mb-8">
                <div className={`w-12 h-12 lg:w-16 lg:h-16 bg-gradient-to-br ${category.color} rounded-2xl flex items-center justify-center mr-4 lg:mr-6 group-hover:scale-110 transition-transform duration-300`}>
                  <div className="text-white">{category.icon}</div>
                </div>
                <h3 className="text-xl lg:text-2xl font-bold text-gray-900">{category.title}</h3>
              </div>
              
              <div className="space-y-6">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="group">
                    <div className="flex justify-between items-center mb-3">
                      <span className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                        {skill.name}
                      </span>
                      <span className="text-sm font-medium text-gray-600">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div 
                        className={`h-full bg-gradient-to-r ${category.color} rounded-full transition-all duration-1000 ease-out`}
                        style={{ 
                          width: isVisible ? `${skill.level}%` : '0%',
                          transitionDelay: `${skillIndex * 200}ms`
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* AI & Automation Section */}
        <div className={`${isVisible ? 'animate-fadeInUp stagger-6' : 'opacity-0'}`}>
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-8 lg:p-12 rounded-3xl">
            <div className="text-center mb-12">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">AI & Automation</h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Leveraging cutting-edge AI technologies to build intelligent automation workflows
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {aiTools.map((tool, index) => (
                <div 
                  key={index}
                  className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 text-center group"
                >
                  <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                    {tool.icon}
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-2">{tool.name}</h4>
                  <p className="text-gray-600">{tool.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Skills Summary */}
        <div className={`mt-20 text-center ${isVisible ? 'animate-fadeInUp stagger-7' : 'opacity-0'}`}>
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-8 lg:p-12 rounded-3xl text-white">
            <h3 className="text-3xl font-bold mb-6">Ready to Build the Future</h3>
            <p className="text-xl opacity-90 max-w-3xl mx-auto leading-relaxed">
              Combining quality engineering expertise with modern data technologies to deliver robust, scalable solutions. 
              Always learning, always growing, always ready for the next challenge.
            </p>
            <div className="flex justify-center mt-8">
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full">
                <Zap className="w-5 h-5" />
                <span className="font-semibold">Continuously Evolving</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;