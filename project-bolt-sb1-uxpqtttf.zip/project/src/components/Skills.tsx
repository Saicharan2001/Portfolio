import React from 'react';
import { Code2, Database, Cloud, Brain } from 'lucide-react';

const skillCategories = [
  {
    title: 'Programming Languages',
    icon: <Code2 className="w-6 h-6" />,
    skills: ['C', 'C++', 'Python', 'JavaScript', 'TypeScript'],
  },
  {
    title: 'Web Development',
    icon: <Code2 className="w-6 h-6" />,
    skills: ['React.js', 'Node.js', 'HTML5', 'CSS3', 'Tailwind CSS'],
  },
  {
    title: 'Cloud & DevOps',
    icon: <Cloud className="w-6 h-6" />,
    skills: ['Microsoft Azure', 'Azure DevOps', 'CI/CD', 'Docker'],
  },
  {
    title: 'Data & AI',
    icon: <Brain className="w-6 h-6" />,
    skills: ['SQL', 'Machine Learning', 'Data Science', 'Power BI'],
  },
];

const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Skills & Expertise</h2>
          <div className="mt-4 h-1 w-20 bg-blue-600 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4">
                <div className="text-blue-600 mr-3">{category.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900">{category.title}</h3>
              </div>
              <ul className="space-y-2">
                {category.skills.map((skill, skillIndex) => (
                  <li key={skillIndex} className="flex items-center text-gray-600">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;